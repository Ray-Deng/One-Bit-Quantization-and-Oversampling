function Transfer_prob=calculate_transfer_prob_H(H_transfer_prob,F_integral_all,SNR,n,W_eta_update)
[N_wave,N]=size(F_integral_all);
sigma1_inv=((10.^((SNR)/10))*((n+1)*W_eta_update)).^(0.5);
Transfer_prob = sparse(zeros(N_wave,2^N));
H_pos1_x=(qfunc((-F_integral_all)'.*(ones(N,1)*sigma1_inv)))';
H_pos1_x(find(H_pos1_x==0))=4.9407e-324;
H_neg1_x=(qfunc((F_integral_all)'.*(ones(N,1)*sigma1_inv)))';
H_neg1_x(find(H_neg1_x==0))=4.9407e-324;
for i=1:N_wave
    Transfer_prob_sub1=H_pos1_x(i,:).*double(H_transfer_prob);
    Transfer_prob_sub1(Transfer_prob_sub1==0)=1;
    Transfer_prob_sub2=H_neg1_x(i,:).*double(flipud(H_transfer_prob));
    Transfer_prob_sub2(Transfer_prob_sub2==0)=1;
    Transfer_prob_sub_all(i,:)=prod(Transfer_prob_sub1',1).*prod(Transfer_prob_sub2',1);
end
Transfer_prob_sub_all(Transfer_prob_sub_all<1e-12)=0;
Transfer_prob=sparse(Transfer_prob_sub_all);
end
