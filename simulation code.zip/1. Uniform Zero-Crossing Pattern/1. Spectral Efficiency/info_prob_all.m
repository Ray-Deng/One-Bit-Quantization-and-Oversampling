function info_all=info_prob_all(n,Tru_L)
info_all=strings((n+1)^(Tru_L),1);
for i=1:(n+1)^(Tru_L)
    num=i-1;
    info_all(i,1)=dec2base(num,n+1,Tru_L);
end
end