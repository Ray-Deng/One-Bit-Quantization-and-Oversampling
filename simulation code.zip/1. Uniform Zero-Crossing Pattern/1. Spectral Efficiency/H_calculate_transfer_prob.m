function H_transfer_prob=H_calculate_transfer_prob(n_slot)
H_transfer_prob=zeros(2^n_slot,n_slot);
for i=1:2^n_slot
num=i-1;
k=0;
while num~=0
    H_transfer_prob(i,n_slot-k)=mod(num,2);
    num=floor(num/2);
    k=k+1;
end
end
end