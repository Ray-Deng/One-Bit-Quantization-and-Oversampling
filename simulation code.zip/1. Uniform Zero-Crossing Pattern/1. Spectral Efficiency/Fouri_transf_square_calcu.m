function [f_alt,G_u2]=Fouri_transf_square_calcu(n,kappa,t_Ny,t_interval,t,f_trun,g_u)
[n_row,n_col]=size(g_u);
N_wave=n_row;
P_tru=1/(N_wave)*ones(1,N_wave);
P=1/(N_wave);
mf=t_Ny/t_interval/2*kappa;
f_alt=[-mf:0.01:mf]*f_trun;
G_u=g_u*t_interval*exp(-1i*2*pi*f_alt'*t)';
G_u2=abs(G_u).^2;
end