function win_cos_normal=win_cos(alpha,kappa,t_Ny,t)
t_trun=kappa*t_Ny
if alpha==0
    win_cos_normal=ones(1,length(t));
else
    A=1;
    t_cos1=(1-alpha)*t_trun/2;
    t_cos2=t_trun/2;
    if mod(kappa,2)==1
        t_cos_all=t;
    else
        t_cos_all=t-t_Ny/2;
    end
    a_cos=(2*pi)/(alpha*t_trun);
    b_cos=((1-alpha)*t_trun)/2;
    for i=1:length(t_cos_all)
        if abs(t_cos_all(i))<t_cos1
            y_cos(i)=A;
        else
            y_cos(i)=(A/2)*(1+cos(a_cos*(t_cos_all(i)-b_cos)));
        end
    end
    win_cos_normal=y_cos;
end
end