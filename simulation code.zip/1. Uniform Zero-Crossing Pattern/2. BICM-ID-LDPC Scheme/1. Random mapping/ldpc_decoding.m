function [Lq_all,decoded_bits,decoded_info_bits]=ldpc_decoding(H,L_chx,H_row,N_LDPC,N_info,max_run)
for i_dx=1:length(L_chx)/N_LDPC
    Lc =L_chx((i_dx-1)*N_LDPC+1:i_dx*N_LDPC);
    for i=1:N_LDPC
        for j=1:H_row
            if H(j,i) == 1
                Lq(i,j) =  Lc(i);
            end
        end
    end  
    for n_run = 1:max_run
        for j=1:H_row
            for i=1:N_LDPC
                phi = 0;
                alpha_pre = 1;
                for k_L = 1: N_LDPC
                    if (H(j,k_L) == 1) && (k_L ~= i)
                        beta = abs(Lq(k_L,j));
                        alpha=sign(Lq(k_L,j));
                        alpha_pre = alpha_pre * alpha;
                        if beta>709
                            phi=phi+log(1);
                        else
                            phi = phi+log((exp(beta)+1)/(exp(beta)-1));
                        end
                    end
                end
                if phi<1e-20
                    phi=1e-10;
                end
                if H(j,i)==1
                    if phi>=709
                        phi = log(1);
                    else
                        phi = log((exp(phi)+1)/(exp(phi)-1));
                    end
                    Lr(j,i) = alpha_pre * phi;
                end
            end
        end
        Lq = zeros(N_LDPC,H_row);
        for i=1:N_LDPC
            for j = 1: H_row
                LR=0;
                for k_L=1:H_row
                    if(H(k_L,i) == 1)&& (k_L ~= j)
                        LR=LR+Lr(k_L,i);
                    end
                end
                if H(j,i)==1
                    Lq(i,j) = LR + Lc(i);
                end
            end
        end
        LQ = zeros(1,N_LDPC);
        for i=1:N_LDPC
            QL=0;
            count_Num=1;
            for j=1:H_row
                if H(j,i)==1
                    count_Num=count_Num+1;
                    QL=QL+Lr(j,i);
                end
            end
            LQ(i) = QL + Lc(i);
            if LQ(i)<0
                c1(i)=1;
            else
                c1(i)=0;
            end
        end
        i_dx;
        n_run;
        LQ;
        if mod(c1*H',2)==0;
            break;
        end
    end 
    Lq_all((i_dx-1)*N_LDPC+1:i_dx*N_LDPC)=LQ;
    decoded_bits((i_dx-1)*N_LDPC+1:i_dx*N_LDPC)=c1;
    decoded_info_bits((i_dx-1)*N_info+1:(i_dx-1)*N_info+N_info)=c1(H_row+1:N_LDPC);
end
end