function [S,P_S]=mapping(c_bits,Block_Num,kappa,N_map,t_interval,t_Ny,info_all,g_u)
if mod(kappa,2)==1 
    t=-t_Ny*kappa/2:t_interval:t_Ny*kappa/2-t_interval; 
else 
    t=-(t_Ny*kappa-1)/2:t_interval:(t_Ny*kappa+1)/2-t_interval;
end
k=length(t);
for i=1:Block_Num 
    S_block=g_u(find(all(info_all==kron(c_bits((i-1)*(kappa*N_map)+1:i*(kappa*N_map)),ones(2^(N_map*kappa),1)),2)),:);
    P_S(i)=sum(S_block.^2*t_interval/(kappa*t_Ny));
    S((i-1)*k+1:i*k)=S_block; 
end
end