function [F]=construction_Zakai(m,tau,t)
if mod(m,2)==1 
    for i=1:length(t)
        fuc=1;
        for k=1:(m-1)/2
            fuc=fuc*(1-t(i)/tau(k))*(1-t(i)/tau(m-k+1)); 
        end
        fuc=fuc*(t(i)-tau((m+1)/2)); 
        F(i)=fuc;
    end
else % ���m��ż��
    for i=1:length(t)
        fuc=1;
        for k=1:m/2
            fuc=fuc*(1-t(i)/tau(k))*(1-t(i)/tau(m-k+1));
        end
        F(i)=fuc;
    end
end
end