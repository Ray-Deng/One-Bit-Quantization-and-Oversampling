function index=index_neighbour_remain(Pro_G_u2_index_remain,N_map,kappa)
Num_remain=length(Pro_G_u2_index_remain);
Pro_G_u2_index_remain_zc=zeros(Num_remain,kappa);
index=zeros(Num_remain,1);
for i=1:Num_remain
    Pro_G_u2_index_remain_i_dec=dec2bin(Pro_G_u2_index_remain(i),N_map*kappa);
    for j=1:kappa
        Pro_G_u2_index_remain_zc(i,j)=bin2dec(gray2dec_char(Pro_G_u2_index_remain_i_dec(j*N_map-1:j*N_map)));
    end
end
for i=1:Num_remain
    index_neighbour=zeros(1,kappa);
    for j=1:2*kappa
        index_neighbour=Pro_G_u2_index_remain_zc(i,:);
        index_neighbour(ceil(j/2))=index_neighbour(ceil(j/2))+(1-2*mod(j,2));
        if ~isempty(find(sum(Pro_G_u2_index_remain_zc==index_neighbour,2)==kappa)) 
            index(i,j)=Pro_G_u2_index_remain(find(sum(Pro_G_u2_index_remain_zc==index_neighbour,2)==kappa));
        end
    end
end 
end