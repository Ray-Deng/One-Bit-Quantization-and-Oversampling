%% main function��������������������������
%Achievable SE versus SNR


%% clear��������������������������
clc;
clear;


%% Setting Parameter��������������������������
t_Ny=1; %length of a Nyquist interval
W_eta=1; %fractional power containment bandwidth (default value)
kappa=3; %truncation interval %kappa
t_trun=t_Ny*kappa %Number of Nyquist intervals of truncated waveform
f_trun=1/t_trun;
SNR=[23]; %signal-to-noise-ratio
alpha=[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1]; %roll-off factor
eta=0.95 %fraction %eta
m=1000001;       %number of super-Nyquist interval
n=3 %Oversampling factor-1
t_interval=t_Ny/(60*(n+1)); %Waveform resolution


%% obtain waveforms��������������������������
if mod(kappa,2)==1 %kappa is odd
    t=-t_Ny*kappa/2:t_interval:t_Ny*kappa/2-t_interval; %waveform interval
else %kappa is even
    t=-(t_Ny*kappa-1)/2:t_interval:(t_Ny*kappa+1)/2-t_interval; %waveform interval
end

M=(n+1)^(kappa); %maximum size of waveform set
wave_Num=2*(n+1)^kappa:-2:2; 
n_integra=kappa*(n+1); %integration times %n_integra
g_u_hard=zeros(M,length(t)); %initialize waveforms (hard truncation)

%construct waveforms (hard truncation)
info_all=info_prob_all(n,kappa);
for j=1:M
    tau=tau_encoding(n,m,info_all(j,1),kappa,t_Ny); %zero-crossings (uniform zero-crossing pattern)
    g_u_hard(j,:)=construction_Zakai(m,tau,t);
end


%% calculate spectral efficiency��������������������������
for alpha_Num=1:length(alpha)
    g_u=zeros(2*M,length(t)); %initialize waveforms (soft truncation)
    P_gu=zeros(1,2*M); %Initialize the power of g_u
    g_u_integra=zeros(2*M,n_integra); %Initialize the integral value of g_u
    win_cos_normal=win_cos(alpha(alpha_Num),kappa,t_Ny,t); %raised cosine window
    for j=1:M
        g_u(j,:)=g_u_hard(j,:).*win_cos_normal; %soft truncation
        P_gu(1,j)=sum(g_u(j,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
    end
    g_u(M+1:2*M,:)=-g_u(1:M,:); %antipodal pairs
    P_gu(1,M+1:2*M)=P_gu(1,1:M);
    
    g_u=g_u./sqrt(P_gu)'; %normalized power
    
    %integration
    for j=1:2*M
        g_u_integra(j,:)=integral_function(n_integra,t_interval,g_u(j,:),n,t_Ny);
    end

    %calculate the square of the Fourier transform
    [f,G_u2]=Fouri_transf_square_calcu(n,kappa,t_Ny,t_interval,t,f_trun,g_u);

    %calculate the achievable rate
    [SE_pair,W_eta_pair,G_u_pair_index]=obtain_SE(n,kappa,alpha_Num,t_interval,g_u_integra,wave_Num,eta,t_Ny,G_u2,f_trun,SNR,f,W_eta);
    SE_all(alpha_Num,:)=SE_pair;
    W_eta_all(alpha_Num,:)=W_eta_pair;
    G_u_index(alpha_Num,:)=G_u_pair_index;
end

figure
plot(wave_Num(length(wave_Num):-1:1)/2,SE_all(1,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(2,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(3,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(4,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(5,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(6,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(7,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(8,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(9,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(10,length(wave_Num):-1:1),wave_Num(length(wave_Num):-1:1)/2,SE_all(11,length(wave_Num):-1:1))
grid on;
legend('\alpha=0','\alpha=0.1','\alpha=0.2','\alpha=0.3','\alpha=0.4','\alpha=0.5','\alpha=0.6','\alpha=0.7','\alpha=0.8','\alpha=0.9','\alpha=1')
xlabel('M/2');
ylabel('Spectral Efficiency (bit/dim.)');


