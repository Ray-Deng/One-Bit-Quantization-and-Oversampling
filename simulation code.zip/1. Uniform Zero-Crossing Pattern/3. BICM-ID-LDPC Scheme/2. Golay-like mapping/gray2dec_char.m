function Pro_G_u2_index_remain_i=gray2dec_char(Pro_G_u2_index_remain_i_dec_j)
Num_Pro=length(Pro_G_u2_index_remain_i_dec_j);
for i=1:Num_Pro
    Pro(i)=str2num(Pro_G_u2_index_remain_i_dec_j(i));
end
Pro_char=gray2dec(Num_Pro,Pro);
for i=1:Num_Pro
    Pro_G_u2_index_remain_i(i)=num2str(Pro_char(i));
end
end
