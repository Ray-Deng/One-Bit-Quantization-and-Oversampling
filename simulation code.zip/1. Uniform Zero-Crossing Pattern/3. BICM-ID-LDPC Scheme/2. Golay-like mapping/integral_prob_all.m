function [g_u_integra,P_gu,g_u]=integral_prob_all(alpha,n,m,kappa,N_map,t_interval,info_wave,t_Ny,Pro_G_u2_index)
%waveform interval
if mod(kappa,2)==1
    t=-t_Ny*kappa/2:t_interval:t_Ny*kappa/2-t_interval;
else
    t=-(t_Ny*kappa-1)/2:t_interval:(t_Ny*kappa+1)/2-t_interval;
end
%raised cosine window
win_cos_normal=win_cos(alpha,kappa,t_Ny,t);
%initialization
wave_Num=size(info_wave,1);
n_integra=kappa*(n+1);
g_u_hard_orig=zeros(wave_Num,length(t));
g_u_orig=zeros(wave_Num,length(t));
P_gu_orig=zeros(1,wave_Num);
g_u_integra_orig=zeros(wave_Num,n_integra);
%construction of waveforms
for i=1:wave_Num
    tau=tau_encoding(n,m,t,info_wave(i,:),kappa,t_Ny); %zero-crossings (uniform zero-crossing pattern)
    g_u_hard_orig(i,:)=construction_Zakai(m,tau,t); %waveforms
    g_u_orig(i,:)=win_cos_normal.*g_u_hard_orig(i,:); %soft truncation
    P_gu_orig(1,i)=sum(g_u_orig(i,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
    g_u_orig(i,:)=g_u_orig(i,:)/sqrt(P_gu_orig(1,i)); %normalization
    P_gu_orig(1,i)=sum(g_u_orig(i,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
    g_u_integra_orig(i,:)=integral_function(n_integra,t_interval,g_u_orig(i,:),N_map,t_Ny); %integration
end

%%Golay-like mapping
%initialization
g_u=zeros(wave_Num,length(t));
P_gu=zeros(1,wave_Num);
g_u_integra=zeros(wave_Num,n_integra); 
%mapping ii)
index=Pro_G_u2_index(find(Pro_G_u2_index<=wave_Num/2)); 
g_u(index,:)=g_u_orig(index,:);
P_gu(1,index)=P_gu_orig(1,index);
g_u_integra(index,:)=g_u_integra_orig(index,:);
%mapping iii)
info_index_remain=setdiff([1:wave_Num/2],Pro_G_u2_index);
Pro_G_u2_index_remain=Pro_G_u2_index(find(Pro_G_u2_index<=wave_Num&Pro_G_u2_index>wave_Num/2));
distribution_index=remain_distribution_index(N_map,kappa,Pro_G_u2_index_remain,info_index_remain); %���䷽ʽ��index
g_u(info_index_remain,:)=g_u_orig(distribution_index,:);
P_gu(1,info_index_remain)=P_gu_orig(1,distribution_index);
g_u_integra(info_index_remain,:)=g_u_integra_orig(distribution_index,:);

%antipodal pairs
g_u(wave_Num/2+1:wave_Num,:)=-g_u(wave_Num/2:-1:1,:);
g_u_integra(wave_Num/2+1:wave_Num,:)=-g_u_integra(wave_Num/2:-1:1,:);
P_gu(1,wave_Num/2+1:wave_Num)=P_gu(1,wave_Num/2:-1:1);
end