function [H]=getH(m,n)
row_flag(1:m)=0;
h=zeros(m,n);
bits_per_col=3;                                                          
for i=1:n
    a=randperm(m);
    for j=1:bits_per_col
        h(a(j),i)=1;
      row_flag(a(j))= row_flag(a(j))+1;
    end
end                                                                       
max_ones_per_row=ceil(n*bits_per_col/m);                                 
for i=1:m                                                                  
    if row_flag(i)==0
        for k=1:2  
            j=unidrnd(m);                                                 
            while  h(i,j)==1
                j=unidrnd(m);
            end
            h(i,j)=1;
            row_flag(i)=row_flag(i)+1;
        end
    end
    if  row_flag(i)==1
         j=unidrnd(m);
            while  h(i,j)==1
                j=unidrnd(m);
            end
            h(i,j)=1;
            row_flag(i)=row_flag(i)+1;
    end
end
          
for i=1:m                                                                  
    j=1;
    a=randperm(n);
    while row_flag(i)>max_ones_per_row                                   
        if h(i,a(j))==1                                                   
            newrow=unidrnd(m);                                          
            k=0;
            while (row_flag(newrow)>=max_ones_per_row|h(newrow,a(j))==1)&k<m
                newrow=unidrnd(m);
                k=k+1;
            end
            if h(newrow,a(j))==0                                           
                h(newrow,a(j))=1;
                row_flag(newrow)=row_flag(newrow)+1;
                h(i,a(j))=0;
                row_flag(i)=row_flag(i)-1;
            end
        end
        j=j+1;
    end
end

for loop=1:100                                    
    success=1;
    for r=1:m
        ones_position=find(h(r,:)==1);            
        ones_count=length(ones_position);
        for i=[1:r-1,r+1:m]
            common=0;
            for j=1:ones_count
                if h(i,ones_position(j))==1
                    common= common+1;
                    if  common==1
                        a=ones_position(j);       
                    end
                end
                if common==2
                    success=0;
                    common=common-1;
                    if (round(rand)==0)            
                        b=a;                      
                        a=ones_position(j);
                    else b=ones_position(j);       
                    end
                    h(i,b)=3;                      
                    newrow=unidrnd(m);
                    iteration=0;
                    while h(newrow,b)~=0 & iteration<5
                        newrow=unidrnd(m);
                        iteration=iteration+1;
                    end
                    if iteration>=5                   
                        while h(newrow,b)==1
                           newrow=unidrnd(m);
                        end
                    end
                    h(newrow,b)=1;                   
                end
            end
        end
    end
    if success                                        
        break
    end
end
h=h==1;                                              
H=h;