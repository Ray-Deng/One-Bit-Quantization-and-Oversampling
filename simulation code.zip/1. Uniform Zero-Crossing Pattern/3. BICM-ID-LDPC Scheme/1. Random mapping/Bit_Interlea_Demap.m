%bit��֯�����ӳ��

function L_chc=Bit_Interlea_Demap(NumI,N_map,B,info_all,g_u_integra,P_gu,SNR,Pri_prob,Block_Num,kappa,t_Ny,W_eta)
sigma1_inv=((10.^((SNR)/10))./P_gu*(2^N_map*W_eta/t_Ny)).^(0.5);
Num_Truncat=kappa*N_map;
L_chc=zeros(1,Block_Num*Num_Truncat);
for i=1:Block_Num
    for j=1:Num_Truncat
        exp_up=exp((1-info_all(find(info_all(:,j)==0),[(1:j-1),(j+1:Num_Truncat)]))*[Pri_prob((i-1)*Num_Truncat+1:(i-1)*Num_Truncat+j-1),Pri_prob((i-1)*Num_Truncat+j+1:i*Num_Truncat)]');
        exp_up(find(isinf(exp_up)))=sign(exp_up(find(isinf(exp_up))))*1.7976e+308;
        exp_down=exp((1-info_all(find(info_all(:,j)==1),[(1:j-1),(j+1:Num_Truncat)]))*[Pri_prob((i-1)*Num_Truncat+1:(i-1)*Num_Truncat+j-1),Pri_prob((i-1)*Num_Truncat+j+1:i*Num_Truncat)]');
        exp_down(find(isinf(exp_down)))=sign(exp_down(find(isinf(exp_down))))*1.7976e+308;
        log_up=(exp_up'*prod(qfunc(g_u_integra(find(info_all(:,j)==0),:).*((-B((i-1)*kappa*(2^N_map)+1:i*kappa*(2^N_map)))'*sigma1_inv(1,find(info_all(:,j)==0)))'),2));
        log_up(find(isinf(log_up)))=sign(log_up(find(isinf(log_up))))*1.7976e+308;
        log_down=(exp_down'*prod(qfunc(g_u_integra(find(info_all(:,j)==1),:).*((-B((i-1)*kappa*(2^N_map)+1:i*kappa*(2^N_map)))'*sigma1_inv(1,find(info_all(:,j)==1)))'),2));
        log_down(find(isinf(log_down)))=sign(log_down(find(isinf(log_down))))*1.7976e+308;
        L_chc((i-1)*Num_Truncat+j)=log(log_up/log_down);
        L_chc(find(isinf(L_chc)))=sign(L_chc(find(isinf(L_chc))))*1.7976e+308;
    end
end
end