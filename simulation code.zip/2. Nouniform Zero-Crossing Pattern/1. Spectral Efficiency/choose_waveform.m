function find_index=choose_waveform(f,find_index_length,index_all_same_col,index_all_remain,t_Nyinterval_choise,judge_size,index_all_same)
find_index=zeros(1,find_index_length);
find_index(1:find_index_length-index_all_same_col)=index_all_remain;
index_f_alt=find(abs(f-t_Nyinterval_choise/2)<0.0000001);
choise_judge_size=judge_size(:,index_f_alt)';
index_good_waveform=choise_judge_size.*index_all_same(1,:)+(1-choise_judge_size).*index_all_same(2,:);
find_index(find_index_length-index_all_same_col+1:find_index_length)=index_good_waveform;
find_index=sort(find_index);
end