function [index_all_remain,index_all_same]=search_pair_wavef(wave_integral,n,Tru_L)
n_wave=(n+1)^(Tru_L);
a_search_original=wave_integral(1:n_wave/(n+1),:);
a_search_compare=-wave_integral(n_wave/(n+1)+1:n_wave,:);
a_search_original_dec=zeros(1,n_wave/(n+1));
a_search_compare_dec=zeros(1,n_wave/(n+1)*n);
for j=1:n_wave/(n+1) 
    for k=1:(n*Tru_L)
        a_search_original_dec(j)=a_search_original_dec(j)+a_search_original(j,n*Tru_L-k+1)*2^(k-1);
    end
end
for j=1:n_wave/(n+1)*n
    for k=1:(n*Tru_L)
        a_search_compare_dec(j)=a_search_compare_dec(j)+a_search_compare(j,n*Tru_L-k+1)*2^(k-1);
    end
end
all_remain=ones(1,n_wave)
index_all_remain=zeros(1,(n_wave-2^Tru_L));
index_all_same=zeros(2,2^(Tru_L-1));
count=1;
for j=1:n_wave/(n+1)
    if sum(a_search_original_dec(j)==a_search_compare_dec)>0;
        all_remain(1,[j,n_wave/(n+1)+find(a_search_original_dec(j)==a_search_compare_dec)])=0;
        index_all_same(1,count)=j;
        index_all_same(2,count)=n_wave/(n+1)+find(a_search_original_dec(j)==a_search_compare_dec);
        count=count+1;
    end
end
index_all_remain=find(all_remain~=0);
end