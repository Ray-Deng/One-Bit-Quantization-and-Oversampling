function [f_alt,G_u2]=Fouri_transf_square_calcu(n,Tru_L,t_Nyinterval,t_interval,t,f_tru,F_all)
[n_row,n_col]=size(F_all);
N_wave=n_row;
P_tru=1/(N_wave)*ones(1,N_wave);
P=1/(N_wave);
mf=t_Nyinterval/t_interval/2*Tru_L;
f_alt=[-mf:0.01:mf]*f_tru;
G_u=F_all*t_interval*exp(-1i*2*pi*f_alt'*t)'; 
G_u2=abs(G_u).^2;
end