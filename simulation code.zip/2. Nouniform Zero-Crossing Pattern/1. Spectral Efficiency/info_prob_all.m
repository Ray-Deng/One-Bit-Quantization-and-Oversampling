function info_all=info_prob_all(n,kappa)
info_all=strings((n+1)^(kappa),1);
for i=1:(n+1)^(kappa)
    num=i-1;
    info_all(i,1)=dec2base(num,n+1,kappa);
end
end