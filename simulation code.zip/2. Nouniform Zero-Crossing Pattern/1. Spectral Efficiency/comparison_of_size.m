function judge_size=comparison_of_size(Tru_L,f_alt,G_u_same1,G_u_same2)
f_alt_middle_num=(length(f_alt)+1)/2;
judge_size=zeros(1,length(f_alt));
%G_u2_same1=abs(G_u_same1).^2;
%G_u2_same2=abs(G_u_same2).^2;
G_u2_same1=abs(G_u_same1(:,f_alt_middle_num:length(f_alt)));
G_u2_same1(:,1)=G_u2_same1(:,1)/2;
G_u2_same2=abs(G_u_same2(:,f_alt_middle_num:length(f_alt)));
G_u2_same2(:,1)=G_u2_same2(:,1)/2;
G_u2_same1_sum=cumsum(G_u2_same1,2);
G_u2_same2_sum=cumsum(G_u2_same2,2);
for j=1:2^(Tru_L-1)
    for k=1:f_alt_middle_num
        if G_u2_same1_sum(j,k)>=G_u2_same2_sum(j,k)
            judge_size(j,[f_alt_middle_num-(k-1),f_alt_middle_num+(k-1)])=1;
        %else
        %    judge_size(j,[f_alt_middle_num-(k-1),f_alt_middle_num+(k-1)])=-j;
        end
    end
end
end