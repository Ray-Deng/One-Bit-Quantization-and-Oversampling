%% main function��������������������������
%Achievable SE versus SNR


%% clear��������������������������
clc;
clear;


%% Setting Parameter��������������������������
t_Ny=1; %length of a Nyquist interval
W_eta=1; %fractional power containment bandwidth (default value)
kappa=3; %truncation interval %kappa
t_trun=t_Ny*kappa %Number of Nyquist intervals of truncated waveform
f_trun=1/t_trun;
SNR=[5 10]; %signal-to-noise-ratio
alpha=[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1]; %roll-off factor
eta=0.95 %fraction %eta
m=1000001;       %number of super-Nyquist interval
n=1 %Oversampling factor
t_interval=t_Ny/(60*(n+1)); %Waveform resolution


%% obtain waveforms��������������������������
if mod(kappa,2)==1 %kappa is odd
    t=-t_Ny*kappa/2:t_interval:t_Ny*kappa/2-t_interval; %waveform interval
else %kappa is even
    t=-(t_Ny*kappa-1)/2:t_interval:(t_Ny*kappa+1)/2-t_interval; %waveform interval
end

M=(n+1)^(kappa); %maximum size of waveform set 
n_integra=kappa*n; %integration times %n_integra
g_u_hard=zeros(M,length(t)); %initialize waveforms (hard truncation)

%construct waveforms (hard truncation)
info_all=info_prob_all(n,kappa);
for j=1:M
    tau=tau_encoding(n,m,info_all(j,1),kappa,t_Ny); %zero-crossings (nouniform zero-crossing pattern)
    g_u_hard(j,:)=construction_Zakai(m,tau,t);
end

%% pairing
wave_integral=construct_wave_integral(n,kappa,g_u_hard,t_Ny,t,n_integra,t_interval);
[index_all_remain,index_all_same]=search_pair_wavef(wave_integral,n,kappa);
[index_all_same_row,index_all_same_col]=size(index_all_same);


%% calculate spectral efficiency��������������������������
for alpha_Num=1:length(alpha)
    %initialize waveforms
    g_u_same=zeros(2*index_all_same_col,length(t)); %initialize waveforms (soft truncation)
    P_gu_same=zeros(1,2*index_all_same_col); %initialize the power of g_u
    win_cos_normal=win_cos(alpha(alpha_Num),kappa,t_Ny,t); %raised cosine window
    
    %obtain waveforms
    for j=1:index_all_same_col
        g_u_same(j,:)=g_u_hard(index_all_same(1,j),:).*win_cos_normal; %soft truncation
        P_gu_same(1,j)=sum(g_u_same(j,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
    end
    for j=1:index_all_same_col %antipodal pairs
        g_u_same(index_all_same_col+j,:)=g_u_hard(index_all_same(2,j),:).*win_cos_normal; 
        P_gu_same(1,index_all_same_col+j)=sum(g_u_same(index_all_same_col+j,:).^2*t_interval/(kappa*t_Ny));
    end
    
    g_u_same=g_u_same./sqrt(P_gu_same)'; %normalized power
    
    %calculate the square of the Fourier transform
    [f,G_u2_same]=Fouri_transf_square_calcu(n,kappa,t_Ny,t_interval,t,f_trun,g_u_same);
    judge_size=comparison_of_size(kappa,f,G_u2_same(1:index_all_same_col,:),G_u2_same(index_all_same_col+1:2*index_all_same_col,:));
    
    %calculate the achievable rate
    [SE_alpha_pair,W_eta_SE_alpha_pair]=obtain_SE(index_all_remain,index_all_same_col,W_eta,f,judge_size,index_all_same,t,g_u_hard,win_cos_normal,t_interval,kappa,t_Ny,n,f_trun,eta,n_integra,SNR);
    for SNR_i=1:length(SNR)
        SE_alpha(alpha_Num,SNR_i)=max(SE_alpha_pair(:,SNR_i));
        index_SE_alpha=find(SE_alpha(alpha_Num,SNR_i)==SE_alpha_pair(:,SNR_i));
        W_eta_SE_alpha(alpha_Num,SNR_i)=W_eta_SE_alpha_pair(1,index_SE_alpha(1));
    end
end

%calculate the maximum achievable rate
for SNR_i=1:length(SNR)
    SE(1,SNR_i)=max(SE_alpha(:,SNR_i));
    index_SE=find(SE(1,SNR_i)==SE_alpha(:,SNR_i));
    W_eta_SE(1,SNR_i)=W_eta_SE_alpha(index_SE(1),SNR_i);
end
SE
W_eta_SE
plot(SNR,SE)
grid on;
%title(' ')
xlabel('SNR');
ylabel('Spectral Efficiency');


