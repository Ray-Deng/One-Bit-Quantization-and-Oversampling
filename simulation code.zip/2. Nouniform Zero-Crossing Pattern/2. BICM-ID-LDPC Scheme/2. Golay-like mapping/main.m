%% Main 
%LDPC coded BICM-ID scheme
 

%% clear--------------------------------
clc;
clear;


%% Setting parameters-------------------------------
SNR=[5 10 15 20 25]; %signal-to-noise-ratio
load('SNR23_kappa3_n3_alpha0p1_Ny1_1p3267Hz_095_nouniform') %import the selected waveform
t_Ny=1; %length of a Nyquist interval
W_eta=1.3267; %fractional power containment bandwidth (default value)
kappa=3; %truncation interval %kappa
alpha=0.1;       %roll-off factor
m=1000001;       %number of super-Nyquist interval
N_map=2;    %number of bits per Nyquist interval
n=2^N_map-1;  %oversampling factor
t_interval=t_Ny/(60*(n+1));

N_LDPC=1024; %code length
R_LDPC=0.8125; %code rate
N_info=N_LDPC*R_LDPC;
Num=[20];
Block_Num=1024; %number of symbols
NumOitera=5; %number of Iterations of  demodulator
max_run=50; %number of Iterations of LDPC
col=N_map*kappa;
iol=N_LDPC;


%% LDPC matrix
H_row=N_LDPC*(1-R_LDPC);
H_col=N_LDPC;

calculate matrix
H=getH(H_row,H_col);
[G,valid]=H2G(H);
while valid==0
    H = getH(H_row,H_col); 
    [G,valid]=H2G(H); 
end

%construction of waveform set
info_=info_prob_all(N_map,kappa);
%info_wave_all=info_(Pro_G_u2_index_all,:);
info_wave=info_(1:2^(N_map*kappa),2:N_map*kappa+1);
info_all=info_(1:2^(N_map*kappa),2:N_map*kappa+1);
[g_u_integra,P_gu,g_u]=integral_prob_all(alpha,n,m,kappa,N_map,t_interval,info_wave,t_Ny,Pro_G_u2_index_all,Pro_G_u2_index);

%% BICM-ID-LDPC
for snr_i=1:length(SNR)
    for Num_all=1:Num(snr_i) 
        %source bits
        source_bits=randi([0,1],1,Block_Num*(kappa*N_map)*R_LDPC);
        
        %%LDPC encoding--------------------------------
        for i=1:(Block_Num*(kappa*N_map)*R_LDPC)/N_info
            encoding_bits((i-1)*N_LDPC+1:i*N_LDPC) =mod(source_bits((i-1)*N_info+1:i*N_info)*G,2);
        end
        
        %%interleaver--------------------------------
        c_bits=interleaver_complete(encoding_bits,col,iol);
        
        %%mapping ---------------------------
        [S,P_S]=mapping(c_bits,Block_Num,kappa,N_map,t_interval,t_Ny,info_all,g_u);
        
        %channel--------------------------------
        n_integra_S=kappa*Block_Num*n; 
        S_integral=zeros(1,n_integra_S); 
        S_integral=integral_function(n_integra_S,t_interval,S,N_map,t_Ny);
        
        %noise
        Noise=noise_integral_function(n_integra_S,N_map,SNR(snr_i),Block_Num,P_S,t_Ny,W_eta);
        
        %channel
        Y=S_integral+Noise;
        %quantization
        B=sign(Y);
        

        %%BICM-ID------------------------------
        Pri_prob=zeros(1,Block_Num*(kappa*N_map));
        for NumI=1:NumOitera %ID
            %demapping
            L_chc=Bit_Interlea_Demap(NumI,N_map,B,info_all,g_u_integra,P_gu,SNR(snr_i),Pri_prob,Block_Num,kappa,t_Ny,W_eta);
            
            %deinterleaver
            L_chx=deinterleaver_complete(L_chc,col,iol);
            
            %LDPC decoding
            [La,decoded_bits,decoded_info_bits]=ldpc_decoding(H,L_chx,H_row,N_LDPC,N_info,max_run);
            La1(NumI,:)=La;
            
            %update
            Pri_prob=interleaver_complete(La,col,iol);
            if NumI==1
                BER_num1(Num_all)=sum(decoded_info_bits~=source_bits)/length(source_bits);
            end
            BER_num(NumI,Num_all)=sum(decoded_info_bits~=source_bits)/length(source_bits);
        end
        BER_sub(Num_all)=sum(decoded_info_bits~=source_bits)/length(source_bits);
    end
    BER1(snr_i)=sum(BER_num1)/length(BER_num1) %BICM-LDPC
    BER(snr_i)=sum(BER_sub)/length(BER_sub) %BICM-ID-LDPC
end





