function tau=tau_encoding(n,m,source_bits,Tru_L,t_Nyinterval)
tau=zeros(m,1);
t_all_interval=Tru_L;
m1=(m+mod(t_all_interval+1,2)-t_all_interval)/2;
m2=t_all_interval;    
N=log2(n+1);
source_bits_block=zeros(1,N);
source_bits_block_dec=zeros(1,N);
for i=1:m2
    source_bits_block=source_bits((i-1)*N+1:(i-1)*N+N);
    source_bits_block_dec=gray2dec(N,source_bits_block);
    source_dce=0;
    for l=1:length(source_bits_block_dec)
        source_dce=source_dce+source_bits_block_dec(l)*2^(N-l);
    end
    subinterval=source_dce;
    if (subinterval==0)
        tau_x=t_Nyinterval/n/4-t_Nyinterval/2;
    else
        tau_x=subinterval*t_Nyinterval/n-t_Nyinterval/2;
    end
    tau(m1+i)=tau_x;
end
for i=1:m
    tau(i)=tau(i)+(i-(m+1)/2)*t_Nyinterval;
end
end