function [SE_alpha_pair,W_eta_SE_alpha_pair,G_u_pair_index,G_u_pair_index_selection,waveform_Num]=obtain_SE(M,index_all_remain,index_all_same_col,W_eta,f,judge_size,index_all_same,t,g_u_hard,win_cos_normal,t_interval,kappa,t_Ny,n,f_trun,eta,n_integra,SNR)
find_index_length=length(index_all_remain)+index_all_same_col;
waveform_Num=find_index_length:-1:1;
H_transfer_prob=uint8(H_calculate_transfer_prob(n*kappa));
G_u_pair_index=cell(1,length(waveform_Num));
G_u_pair_index_selection=cell(1,length(waveform_Num));
for Num_wave=1:length(waveform_Num)
    %initialization
    W_eta_update=0;
    W_eta_storage=W_eta;
    while W_eta_update~=W_eta_storage
        W_eta_update=W_eta_storage;
        find_index=choose_waveform(f,find_index_length,index_all_same_col,index_all_remain,W_eta_update,judge_size,index_all_same);
        G_u_pair_index(1,Num_wave)={[find_index,find_index+M]};
        %initialize waveforms
        g_u=zeros(2*find_index_length,length(t)); 
        P_gu=zeros(1,2*find_index_length); 
        
        %obtain waveforms
        for j=1:find_index_length
            g_u(j,:)=g_u_hard(find_index(1,j),:).*win_cos_normal; %soft truncation
            P_gu(1,j)=sum(g_u(j,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
        end
        g_u(find_index_length+1:2*find_index_length,:)=-g_u(1:find_index_length,:);  %antipodal pairs
        P_gu(1,find_index_length+1:2*find_index_length)=P_gu(1,1:find_index_length);
        
        g_u=g_u./sqrt(P_gu)';
        
        [f,choise_index_sort_all,F_wave]=PSD_calcu(n,kappa,t_Ny,t_interval,t,f_trun,g_u,waveform_Num(Num_wave),W_eta_update);
        
        W_eta_storage=bandwidth_bound(f,F_wave,eta);
    end
    G_u_pair_index_selection(1,Num_wave)={choise_index_sort_all};
    %integration
    g_u_integra=zeros(2*waveform_Num(Num_wave),n_integra);
    for j=1:2*waveform_Num(Num_wave)
        g_u_integra(j,:)=integral_function(n_integra,t_interval,g_u(choise_index_sort_all(j),:),n,t_Ny); 
    end
    
    W_eta_SE_alpha_pair(1,Num_wave)=W_eta_storage;
    %calculate achievable rate
    SE_alpha_pair(1,Num_wave)=achieva_rate_calcu(n,kappa,g_u_integra,SNR,H_transfer_prob,W_eta_storage); 
end
end