function [f_alt,choise_index_sort_all,F_wave]=PSD_calcu(n,kappa,t_Ny,t_interval,t,f_trun,g_u,waveform_Num_i,t_Nyinterval_choise_find)
[n_row,n_col]=size(g_u);
N_wave=n_row;
P_tru=1/(N_wave)*ones(1,N_wave);
P=1/(N_wave);
mf=t_Ny/t_interval/2*kappa;
f_alt=[-mf:0.01:mf]*f_trun;
G_u=g_u*t_interval*exp(-1i*2*pi*f_alt'*t)';
G_u_sum=sum(abs(G_u(:,find(abs(f_alt+t_Nyinterval_choise_find/2)<0.0000001):find(abs(f_alt-t_Nyinterval_choise_find/2)<0.0000001))).^2,2)';
[~,sort_index]=sort(G_u_sum(1:N_wave/2));
choise_index=sort_index(1,N_wave/2-waveform_Num_i+1:N_wave/2);
choise_index_sort=sort(choise_index);
choise_index_sort_all=[choise_index_sort,choise_index_sort+N_wave/2];
F_wave=sum(abs(G_u(choise_index_sort_all,:)).^2,1);
end