function wave_integral=construct_wave_integral(n,kappa,g_u_hard,t_Ny,t,n_integra,t_interval)
alpha=0;
g_u=zeros((n+1)^kappa,length(t)); %initialize waveforms (soft truncation)
P_gu=zeros(1,(n+1)^kappa); %Initialize the power of g_u
g_u_integra=zeros((n+1)^kappa,n_integra); %Initialize the integral value of g_u
win_cos_normal=win_cos(alpha(1),kappa,t_Ny,t); %raised cosine window

for j=1:(n+1)^kappa
    g_u(j,:)=g_u_hard(j,:).*win_cos_normal; %soft truncation
    P_gu(1,j)=sum(g_u(j,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
end

g_u=g_u./sqrt(P_gu)'; %normalized power

%integration
for j=1:(n+1)^kappa
    g_u_integra(j,:)=integral_function(n_integra,t_interval,g_u(j,:),n,t_Ny); %��F_block���л���
end

%quantization
wave_integral=sign(g_u_integra);
end