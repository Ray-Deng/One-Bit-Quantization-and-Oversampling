function tau=tau_encoding(n,m,source_bits,kappa,t_Ny)
tau=zeros(m,1);
t_all_interval=kappa;
m1=(m+mod(t_all_interval+1,2)-t_all_interval)/2; %t_all_intervalΪ������ż��ʱ��m1��ȡֵ��ͬ
m2=t_all_interval;          %number of interval of t
source_bits_c=char(source_bits);
for i=1:m2
    if ((gray2bin_dec(n,str2num(source_bits_c(i)))+1)==1)
        tau_x=t_Ny/n/4-t_Ny/2;
    else
        tau_x=(gray2bin_dec(n,str2num(source_bits_c(i))))*t_Ny/n-t_Ny/2;
    end
    tau(m1+i)=tau_x;
end
for i=1:m
    tau(i)=tau(i)+(i-(m+1)/2)*t_Ny;
end
end