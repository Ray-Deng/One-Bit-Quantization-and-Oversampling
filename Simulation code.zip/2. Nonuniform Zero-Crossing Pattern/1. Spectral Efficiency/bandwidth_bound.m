function t_Nyinterval_choise=bandwidth_bound(f,F_wave,eta)
Pro_G_u2=0;
n_f_alt=0;
while Pro_G_u2<eta
    Pro_G_u2=sum(F_wave(1,((length(f)+1)/2)-n_f_alt:((length(f)+1)/2)+n_f_alt))/sum(F_wave);
    n_f_alt=n_f_alt+1;
end
t_Nyinterval_choise=f(((length(f)+1)/2)+(n_f_alt-1))-f(((length(f)+1)/2)-(n_f_alt-1));
end