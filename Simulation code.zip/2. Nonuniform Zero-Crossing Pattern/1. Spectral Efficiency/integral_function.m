function F_integral=integral_function(n_integra,t_interval,g_u_i,n,t_Ny)
F_integral=zeros(1,n_integra);
index=1;
for i=1:n_integra     
    f_integral=0; 
    for j=1:t_Ny/t_interval/n
        f_integral=f_integral+g_u_i(index)*t_interval;       
        index=index+1;
    end 
    F_integral(i)=f_integral;   
end
end
