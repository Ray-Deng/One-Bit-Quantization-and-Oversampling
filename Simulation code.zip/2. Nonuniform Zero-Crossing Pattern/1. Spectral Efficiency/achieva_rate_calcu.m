function [SE_alpha_pair]=achieva_rate_calcu(n,kappa,g_u_integra,SNR,H_transfer_prob,W_eta_storage)
[N_wave,N]=size(g_u_integra);
g_u_integra_choise=g_u_integra;
SE_alpha_pair=zeros(1,length(SNR));
for SNR_i=1:length(SNR)
    Transfer_prob=calculate_transfer_prob_H(H_transfer_prob,g_u_integra_choise,SNR(SNR_i),n,W_eta_storage);
    t_tru_W_storage=W_eta_storage*kappa;
    x=(1/(N_wave))*ones(1,N_wave);
    [Transfer_prob_row,Transfer_prob_col]=find(Transfer_prob);
    Transfer_prob_row_col=find(Transfer_prob~=0);
    P_y=x*Transfer_prob;
    [P_y_row,P_y_col]=find(P_y);
    log_P_y=sparse(P_y_row,P_y_col,log2(P_y(find(P_y))),1,2^N);
    clear P_y_row;
    clear P_y_col;
    transprob_mul_log_Tranprob_sparse=Transfer_prob(Transfer_prob_row_col).*log2(Transfer_prob(Transfer_prob_row_col));
    %clear Transfer_prob;
    clear Transfer_prob_row_col;
    transprob_mul_log_Tranprob=sparse(Transfer_prob_row,Transfer_prob_col,transprob_mul_log_Tranprob_sparse,N_wave,2^N);
    clear transprob_mul_log_Tranprob_sparse;
    SE_alpha_pair(SNR_i)=-(sum(P_y.*log_P_y,2)-x*sum(transprob_mul_log_Tranprob,2))/t_tru_W_storage;
end
end