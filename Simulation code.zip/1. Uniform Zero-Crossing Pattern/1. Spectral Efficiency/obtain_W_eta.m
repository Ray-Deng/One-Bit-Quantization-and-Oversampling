%calculate fractional power containment bandwidth
function [W_eta_update,G_u_index]=obtain_W_eta(eta,G_u2,f_tru,wave_Num_i,f,W_eta)
[n_wave,~]=size(G_u2);

%initialization
dichotomy_distance=10;
eta_update=0;

%initialize W_eta_update
W_eta_update=W_eta; 
W_eta_storage=W_eta_update;

%initialize the dichotomy interval
dichotomy_left=0; %Left
dichotomy_right=10; %Right

%resolution of f
Resolu_f=0.01*f_tru;

while eta_update~=eta
    if eta_update>eta
        bandwidth_left=find(abs((f+W_eta_storage/2))<Resolu_f/2);
        bandwidth_right=find(abs((f-W_eta_storage/2))<Resolu_f/2);
        if sum(P_index(bandwidth_left(1)+1:bandwidth_right(length(bandwidth_right))-1))/sum(P_index)<eta
            W_eta_storage=f(bandwidth_right(length(bandwidth_right)))-f(bandwidth_left(1));
            break
        end
    end

    P_band_G_u=(sum(G_u2(:,find(abs(f+(0.5*W_eta_update))<(Resolu_f/2)):find(abs(f-(0.5*W_eta_update))<(Resolu_f/2))),2)./sum(G_u2,2))'; %in-band energies
    sort_P_band_G_u=sort(P_band_G_u(1:n_wave/2),'descend'); %sort
    
    %obtain index
    G_u_index=zeros(1,wave_Num_i);
    if sum(P_band_G_u>=(sort_P_band_G_u(wave_Num_i/2)))~=wave_Num_i
        G_u_index(1:length(find(P_band_G_u>(sort_P_band_G_u(wave_Num_i/2)))))=find(P_band_G_u>(sort_P_band_G_u(wave_Num_i/2)));
        length_sub=length(find(P_band_G_u>(sort_P_band_G_u(wave_Num_i/2))));
        index_G_u_equ_sort_G_u=find(P_band_G_u==(sort_P_band_G_u(wave_Num_i/2)));
        G_u_index(length_sub+1:wave_Num_i)=[index_G_u_equ_sort_G_u((wave_Num_i-length_sub)/2),index_G_u_equ_sort_G_u((wave_Num_i-length_sub)/2)+n_wave/2];
    else
        G_u_index=find(P_band_G_u>=(sort_P_band_G_u(wave_Num_i/2)));
    end
    G_u_index=sort(G_u_index);
    
    %calculate bandwidth
    P_index=(1/wave_Num_i)*sum(G_u2(G_u_index,:));
    bandwidth_left=find(abs((f+W_eta_update/2))<Resolu_f/2);
    bandwidth_right=find(abs((f-W_eta_update/2))<Resolu_f/2);
    eta_update=sum(P_index(bandwidth_left(1):bandwidth_right(length(bandwidth_right))))/sum(P_index);
    W_eta_storage=W_eta_update;

    
    if eta_update<eta
        dichotomy_left=W_eta_update;
        W_eta_update=(dichotomy_left+dichotomy_right)/2;
        dichotomy_distance=abs(W_eta_update-dichotomy_left);
    else
        dichotomy_right=W_eta_update;
        W_eta_update=(dichotomy_left+dichotomy_right)/2;
        dichotomy_distance=abs(W_eta_update-dichotomy_right);
    end
end
W_eta_update=W_eta_storage;
bandwidth_left=find(abs(f+W_eta_storage/2)<0.0000001);
bandwidth_right=find(abs(f-W_eta_storage/2)<0.0000001);
sum(P_index(bandwidth_left(1):bandwidth_right(length(bandwidth_right))))/sum(P_index);
if sum(P_index(bandwidth_left(1):bandwidth_right(length(bandwidth_right))))/sum(P_index)<eta
    sum(P_index(bandwidth_left(1):bandwidth_right(length(bandwidth_right))))/sum(P_index)
end
end