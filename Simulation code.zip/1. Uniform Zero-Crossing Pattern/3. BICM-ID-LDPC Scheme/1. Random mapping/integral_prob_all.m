function [g_u_integra,P_gu,g_u]=integral_prob_all(alpha,n,m,kappa,N_map,t_interval,info_wave,t_Ny)
%waveform interval
if mod(kappa,2)==1
    t=-t_Ny*kappa/2:t_interval:t_Ny*kappa/2-t_interval;
else
    t=-(t_Ny*kappa-1)/2:t_interval:(t_Ny*kappa+1)/2-t_interval;
end
%raised cosine window
win_cos_normal=win_cos(alpha,kappa,t_Ny,t);
%initialization
wave_Num=size(info_wave,1);
n_integra=kappa*(n+1);
g_u_integra=zeros(wave_Num,n_integra);
g_u_hard=zeros(wave_Num,length(t));
g_u=zeros(wave_Num,length(t));
P_gu=zeros(1,wave_Num);
%construction of waveforms
for i=1:wave_Num/2 
    tau=tau_encoding(n,m,t,info_wave(i,2:N_map*kappa+1),kappa,t_Ny); %zero-crossings (uniform zero-crossing pattern)
    g_u_hard(i,:)=construction_Zakai(m,tau,t); %waveforms
    g_u(i,:)=win_cos_normal.*g_u_hard(i,:); %soft truncation
    P_gu(1,i)=sum(g_u(i,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
    g_u(i,:)=g_u(i,:)/sqrt(P_gu(1,i)); %normalization
    P_gu(1,i)=sum(g_u(i,:).^2*t_interval/(kappa*t_Ny)); %calculate power 
    g_u_integra(i,:)=integral_function(n_integra,t_interval,g_u(i,:),N_map,t_Ny); %integration
end
%antipodal pairs
g_u_hard(wave_Num/2+1:wave_Num,:)=-g_u_hard(1:wave_Num/2,:);
g_u(wave_Num/2+1:wave_Num,:)=-g_u(1:wave_Num/2,:);
P_gu(1,wave_Num/2+1:wave_Num)=P_gu(1,1:wave_Num/2);
g_u_integra(wave_Num/2+1:wave_Num,:)=-g_u_integra(1:wave_Num/2,:);
end