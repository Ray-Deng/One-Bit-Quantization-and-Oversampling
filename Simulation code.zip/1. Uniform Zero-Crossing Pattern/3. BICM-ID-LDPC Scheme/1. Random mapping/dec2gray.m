function Num1=dec2gray(N,Num)
Num1=zeros(1,N);
Num1(1)=Num(1);
for j=N:-1:2
        Num1(j)=xor(Num(j),Num(j-1));
end
end

