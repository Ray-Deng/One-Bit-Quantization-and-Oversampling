function Noise=noise_integral_function(n_F_integral,N_map,SNR,Block_Num,P_S,t_Ny,W_eta)
n=2^N_map-1;
Noise=zeros(1,n_F_integral);
N_point=n_F_integral/Block_Num; %ÿ���ض����ߵĵ�ĸ���
for i=1:Block_Num;
    Noise((i-1)*N_point+1:i*N_point)=((10.^((SNR)/10))/P_S(i)*(2^N_map*W_eta/t_Ny))^(-0.5)*randn(1,N_point);
end
end
