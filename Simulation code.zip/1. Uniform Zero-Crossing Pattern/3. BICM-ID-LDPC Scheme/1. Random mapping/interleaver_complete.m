function C=interleaver_complete(X,col,iol)
intleav_mat_R=col; 
intleav_mat_C=iol;
intleav_matrix=zeros(intleav_mat_R,intleav_mat_C);
intleav_mat_bits_num=intleav_mat_R*intleav_mat_C;

index_interleaver=zeros(col,iol);
for k=1:col
    index_interleaver(k,:)=k:col:(iol-1)*col+k;
end
for j=1:iol
    index_interleaver(:,j)=circshift(index_interleaver(:,j),[-mod(j-1,col),0]);
end

for k=1:length(X)/intleav_mat_bits_num
    for i=1:intleav_mat_R 
        intleav_matrix(index_interleaver(i,:))=X((i-1)*intleav_mat_C+1:i*intleav_mat_C);
    end
    for j=1:intleav_mat_C 
        C_intleav((j-1)*col+1:j*col)=intleav_matrix(:,j)';
    end
C((k-1)*intleav_mat_bits_num+1:k*intleav_mat_bits_num)=C_intleav;
end
end