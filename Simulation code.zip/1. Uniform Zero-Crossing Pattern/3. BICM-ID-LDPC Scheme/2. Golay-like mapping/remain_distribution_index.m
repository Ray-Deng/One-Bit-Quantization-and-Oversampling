function min_arrange_index=remain_distribution_index(N_map,kappa,Pro_G_u2_index_remain,info_index_remain)
Num_remain=length(Pro_G_u2_index_remain);
arrange_all=perms([1:Num_remain]);
index=index_neighbour_remain(Pro_G_u2_index_remain,N_map,kappa);
min_sum=Num_remain*6*64;
min_arrange_index=zeros(1,Num_remain);
info_=info_prob_all(N_map,kappa);
info_arrange_all=info_(1:2^(N_map*kappa),2:N_map*kappa+1);
for arragne_i=1:factorial(Num_remain) 
    arrange_index=Pro_G_u2_index_remain(arrange_all(arragne_i,:));
    index1=index_new(Num_remain,index,info_index_remain,arrange_index);
    sum_arrange=0; 
    for arragne_j=1:Num_remain 
        sum_arrange=sum_arrange+XOR_array(info_arrange_all(info_index_remain(arragne_j),:),info_arrange_all(index1(arrange_all(arragne_i,arragne_j),find(index(arrange_all(arragne_i,arragne_j),:)~=0)),:));
    end
    if min_sum>sum_arrange
        min_sum=sum_arrange;
        min_arrange_index=arrange_index;
    end
end
end


function sum_xor=XOR_array(A,B)
[B_row,B_col]=size(B);
sum_xor=0;
for row_i=1:B_row
    sum_xor=sum_xor+sum(bitxor(A,B(row_i,:)));
end
end


function index1=index_new(Num_remain,index,info_index_remain,arrange_index)
for i=1:Num_remain
    for j=1:size(index,2)
        a=index(i,j);
        if sum(arrange_index==a)==0
            index1(i,j)=index(i,j);
        else
            index1(i,j)=info_index_remain(find(arrange_index==index(i,j)));
        end
    end
end
end