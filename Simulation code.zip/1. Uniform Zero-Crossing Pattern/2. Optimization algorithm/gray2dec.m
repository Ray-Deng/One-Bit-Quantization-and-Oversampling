function Num2=gray2dec(N,Num1)
Num2=zeros(1,N);
Num2(1)=Num1(1);
for j=2:N
        Num2(j)=xor(Num1(j),Num2(j-1));
end
end


