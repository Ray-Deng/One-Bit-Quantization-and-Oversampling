function [SE_pair,W_eta_all,G_u_pair_index]=obtain_SE(n,kappa,alpha_Num,t_interval,g_u_integra,wave_Num,eta,t_Ny,G_u2,f_tru,SNR,f,W_eta)
[M_wave,N]=size(g_u_integra);
H_transfer_prob=uint8(H_calculate_transfer_prob((n+1)*kappa));
G_u_pair_index=cell(1,length(wave_Num));
for pair_i=1:length(wave_Num)
    [W_eta_update,G_u_index]=obtain_W_eta(eta,G_u2,f_tru,wave_Num(pair_i),f,W_eta);
    W_eta_all(1,pair_i)=W_eta_update;
    G_u_pair_index(1,pair_i)={G_u_index};
    
    if wave_Num(pair_i)==M_wave
        Transfer_prob_all=calculate_transfer_prob_H(H_transfer_prob,g_u_integra,SNR,n,W_eta_update);
        name = ['.\Transfer_prob_data\transfer_prob_',num2str(SNR),'dB_TruL_',num2str(kappa),'_n_',num2str(n),'.mat'];
        save(name,'Transfer_prob_all');
    else
        name = ['.\Transfer_prob_data\transfer_prob_',num2str(SNR),'dB_TruL_',num2str(kappa),'_n_',num2str(n),'.mat'];
        load(name);
    end
    Transfer_prob=Transfer_prob_all(G_u_index,:);
    t_trun_update=W_eta_update*kappa;
    Pr_x=(1/wave_Num(pair_i))*ones(1,wave_Num(pair_i));
    [Transfer_prob_row,Transfer_prob_col]=find(Transfer_prob);
    Transfer_prob_row_col=find(Transfer_prob~=0);
    
    Pr_y=Pr_x*Transfer_prob;
    [P_y_row,P_y_col]=find(Pr_y);
    log_P_y=sparse(P_y_row,P_y_col,log2(Pr_y(find(Pr_y))),1,2^N);
    clear P_y_row;
    clear P_y_col;
    transprob_mul_log_Tranprob_sparse=Transfer_prob(Transfer_prob_row_col).*log2(Transfer_prob(Transfer_prob_row_col));
    clear Transfer_prob_row_col;
    transprob_mul_log_Tranprob=sparse(Transfer_prob_row,Transfer_prob_col,transprob_mul_log_Tranprob_sparse,wave_Num(pair_i),2^N);
    clear transprob_mul_log_Tranprob_sparse;
    SE_pair(1,pair_i)=-(sum(Pr_y.*log_P_y,2)-Pr_x*sum(transprob_mul_log_Tranprob,2))/t_trun_update;
end
end