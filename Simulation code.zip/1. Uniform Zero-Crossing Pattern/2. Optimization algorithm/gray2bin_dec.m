function source_bits_c2_i=gray2bin_dec(n,source_bits_c_i)
source_dec=dec2bin(source_bits_c_i,log2(n+1));
for i=1:log2(n+1)
    source_dec1(i)=str2num(source_dec(i));
end
source_bits_c2_i_bin=gray2dec(log2(n+1),source_dec1);
source_bits_c2_i=0;
for i=1:log2(n+1)
    source_bits_c2_i=source_bits_c2_i+source_bits_c2_i_bin(log2(n+1)-i+1)*2^(i-1);
end
end